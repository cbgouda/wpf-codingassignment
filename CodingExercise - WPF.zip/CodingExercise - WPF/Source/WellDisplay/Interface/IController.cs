﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WellDisplay.PlateView;

namespace WellDisplay.Interface
{
    /// <summary>
    /// Interface to fetch data from Controller to VM
    /// </summary>
    public interface IController
    {
        PlateDisplay GetPlateDisplayObject();
    }
}
