﻿namespace WellDisplay.CommonClasses
{
    /// <summary>
    /// Class to store PlateDropletInfo
    /// </summary>
    public class Plate
    {
        public PlateDropletInfo PlateDropletInfo { get; set; }
    }

    /// <summary>
    /// Class to store DropletInfo
    /// </summary>
    public class PlateDropletInfo
    {
        public DropletInfo DropletInfo { get; set; }
    }

    /// <summary>
    /// Class to store Well array
    /// </summary>
    public class DropletInfo
    {
        public Well[] Wells { get; set; }
    }

    /// <summary>
    /// Class to store Well Data
    /// </summary>
    public class Well
    {
        public string WellName { get; set; }
        public int WellIndex { get; set; }
        public int DropletCount { get; set; }
    }
}
