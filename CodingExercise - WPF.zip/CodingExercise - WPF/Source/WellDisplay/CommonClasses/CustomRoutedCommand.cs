﻿using System;
using System.Windows.Input;

namespace WellDisplay.CommonClasses
{
    /// <summary>
    /// This class is used for handling Command binding actions
    /// </summary>
    public class CustomRoutedCommand:ICommand
    {
        #region private members

        private readonly Action<object> _execute;

        #endregion

        #region Public Event

        public event EventHandler CanExecuteChanged;

        #endregion

        #region Constructor

        public CustomRoutedCommand(Action execute)
        {
            if (execute == null)
            {
                throw new ArgumentNullException("Invalid Commnad");
            }
            this._execute = x=>execute();
        }

        #endregion

        #region public methods

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            if (!CanExecute(parameter))
            {
                throw new InvalidOperationException("Invalid Operation");
            }

            _execute(parameter);
        }

        public void RaiseExecutionChanged()
        {
            OnCanExecuteChanged(EventArgs.Empty);
        }

        #endregion

        #region Event Handlers

        private void OnCanExecuteChanged(EventArgs e)
        {
            CanExecuteChanged?.Invoke(this, e);
        }

        #endregion

    }
}
