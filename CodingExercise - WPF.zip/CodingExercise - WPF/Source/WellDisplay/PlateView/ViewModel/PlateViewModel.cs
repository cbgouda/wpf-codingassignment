﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using WellDisplay.CommonClasses;
using WellDisplay.Interface;

namespace WellDisplay.PlateView
{
    public class PlateViewModel : INotifyPropertyChanged
    {
        #region variables
        private PlateModel _clsPlateModel;
        private Visibility _messageVisibility = Visibility.Visible;
        private Visibility _plateVisibility = Visibility.Collapsed;
        private IController _notifier;

        #endregion

        #region constructor

        public PlateViewModel(PlateModel _clsModel,IController notifier)
        {
            _clsPlateModel = _clsModel;
            SelectCommand = new CustomRoutedCommand(_selectPlateFile);
            UpdateThreshold = new CustomRoutedCommand(_updateThreshold);
            _notifier = notifier;
        }

        #endregion

        #region Properties

        public ICommand SelectCommand { get; private set; }
        
        public ICommand UpdateThreshold { get; private set; }

        public string ThresholdMessage
        {
            get
            {
                return _clsPlateModel.ThresholdMessage;
            }
            set
            {
                _clsPlateModel.ThresholdMessage = value;
                OnPropertyChanged();
            }
        }

        public Visibility MessageVisibility
        {
            get
            {
                return _messageVisibility;
            }
            set
            {
                _messageVisibility = value;
                OnPropertyChanged();
            }
        }

        public Visibility PlateVisibility
        {
            get
            {
                return _plateVisibility;
            }
            set
            {
                _plateVisibility = value;
                OnPropertyChanged();
            }
        }

        #endregion


        #region Events

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        #region Methods

        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        /// <summary>
        /// method to select plate json file and invoke ui updates
        /// </summary>
        private void _selectPlateFile()
        {
            bool _blnPlateFileSelected = _clsPlateModel.SelectPlateFile();
            if (_blnPlateFileSelected)
            {
                MessageVisibility = Visibility.Collapsed;
                PlateVisibility = Visibility.Visible;
                PlateDisplay _plateDisplay = _notifier.GetPlateDisplayObject();
                Plate _plateObject = _clsPlateModel.PlateObject;
                PlateDisplayHelper.DrawGrid(_clsPlateModel.Threshold,_plateDisplay, _plateObject);
            }
        }

        /// <summary>
        /// method to update the threshold value in model and trigger ui changes
        /// </summary>
        private void _updateThreshold()
        {
            if(ThresholdMessage == "")
            {
                ThresholdMessage = "0";
            }
            PlateDisplay _plateDisplay = _notifier.GetPlateDisplayObject();
            _plateDisplay.UpdateThreshold(_clsPlateModel.Threshold);
        }

        #endregion
    }
}
