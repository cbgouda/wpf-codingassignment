﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WellDisplay.CommonClasses;

namespace WellDisplay.PlateView
{
    /// <summary>
    /// Helper class to initiate drawing of plate grid. Can be extended for future use
    /// </summary>
    public static class PlateDisplayHelper
    {
        public static void DrawGrid(int Threshold,PlateDisplay _plateDisplay,Plate _plateData)
        {
            _plateDisplay.ClearGrid();
            switch (_plateData.PlateDropletInfo.DropletInfo.Wells.Length)
            {
                case 48:
                    _plateDisplay.GridSize = 40;
                    _plateDisplay.DrawGrid(7, 9);
                    _plateDisplay.DrawWells(Threshold,_plateData.PlateDropletInfo.DropletInfo.Wells);
                    break;
                case 96:
                    _plateDisplay.GridSize = 30;
                    _plateDisplay.DrawGrid(9, 13);
                    _plateDisplay.DrawWells(Threshold,_plateData.PlateDropletInfo.DropletInfo.Wells);
                    break;
                default:
                    break;
            }
        }

    }
}
