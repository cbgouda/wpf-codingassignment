﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using WellDisplay.Interface;

namespace WellDisplay.PlateView
{
    /// <summary>
    /// Controller class
    /// Responsibility to create View, Model and ViewModel and bind all these 3 together
    /// </summary>
    public class PlateController : IController
    {
        #region Members

        private PlateModel _clsPlateModel;
        private PlateViewModel _clsPlateViewModel;
        private PlateView _uiPlateView;

        #endregion

        #region constructor

        public PlateController()
        {
            initialize();
        }

        #endregion

        #region Methods

        /// <summary>
        /// Initaialization of View , VM and Model
        /// </summary>
        private void initialize()
        {
            _clsPlateModel = new PlateModel();
            _clsPlateViewModel = new PlateViewModel(_clsPlateModel,this);
            _uiPlateView = new PlateView();
            _uiPlateView.DataContext = _clsPlateViewModel;
        }

        /// <summary>
        /// To fetch view of plate
        /// </summary>
        /// <returns></returns>
        public ContentControl GetView()
        {
            return _uiPlateView;
        }

        /// <summary>
        /// To fecth object of plate
        /// </summary>
        /// <returns></returns>
        public PlateDisplay GetPlateDisplayObject()
        {
            return _uiPlateView.objPlate;
        }

        #endregion
    }
}
