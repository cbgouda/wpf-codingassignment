﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WellDisplay.CommonClasses;

namespace WellDisplay.PlateView
{
    /// <summary>
    /// Interaction logic for PlateDisplay.xaml
    /// This xaml file is responsible for displaying the plate and the wells inside it.
    /// </summary>
    public partial class PlateDisplay : ContentControl
    {
        #region Members

        private int _i32GridSize;
        private Grid _childGrid;
        private int _i32Rows;
        private int _i32Cols;
        private List<WellView> _lstWellViews = new List<WellView>();
        private int _i32Threshold;
        private int _i32LowThresholdCount;

        #endregion

        #region Constructor

        public PlateDisplay()
        {
            InitializeComponent();
        }

        #endregion

        #region Properties

        public int GridSize
        {
            set { _i32GridSize = value; }
        }

        #endregion

        #region Methods

        public void DrawGrid(int row, int col)
        {
            _i32Rows = row - 1;
            _i32Cols = col - 1;
            // Defining border and drawing grid
            Border border = new Border();
            border.BorderBrush = Brushes.Black;
            border.BorderThickness = new Thickness(2);
            _childGrid = new Grid();
            border.Height = _childGrid.Height = _i32GridSize * row;
            border.Width = _childGrid.Width = _i32GridSize * col;
            //_childGrid.ShowGridLines = true;
            Grid.SetRow(border, 1);
            Grid.SetRow(_childGrid, 1);
            grdPlate.Children.Add(border);
            grdPlate.Children.Add(_childGrid);

            // Defining GridRowDefinition
            for (int i = 0; i < row; i++)
            {
                RowDefinition _rd = new RowDefinition();
                _rd.Height = new GridLength(_i32GridSize);
                _childGrid.RowDefinitions.Add(_rd);
            }

            // Defining GridColumnDefinition
            for (int i = 0; i < col; i++)
            {
                ColumnDefinition _cd = new ColumnDefinition();
                _cd.Width = new GridLength(_i32GridSize);
                _childGrid.ColumnDefinitions.Add(_cd);
            }

            // Setting the header row values
            char c = 'A';
            for (int i = 1; i < row; i++)
            {
                TextBlock _txtBlock = new TextBlock();
                _txtBlock.Height = _i32GridSize;
                _txtBlock.Text = c.ToString();
                Grid.SetRow(_txtBlock, i);
                Grid.SetColumn(_txtBlock, 0);
                _txtBlock.HorizontalAlignment = HorizontalAlignment.Center;
                _txtBlock.VerticalAlignment = VerticalAlignment.Center;
                _childGrid.Children.Add(_txtBlock);
                c++;
            }

            // Setting the header column values
            for (int i = 1; i < col; i++)
            {
                TextBlock _txtBlock = new TextBlock();
                _txtBlock.Height = _i32GridSize;
                _txtBlock.Text = i.ToString();
                _txtBlock.HorizontalAlignment = HorizontalAlignment.Center;
                _txtBlock.VerticalAlignment = VerticalAlignment.Center;
                Grid.SetRow(_txtBlock, 0);
                Grid.SetColumn(_txtBlock, i);
                _childGrid.Children.Add(_txtBlock);
                c++;
            }
        }

        public void DrawWells(int Threshold,Well[] wells)
        {
            _i32LowThresholdCount = 0;
            _i32Threshold = Threshold;
            for (int i = 0; i < wells.Length; i++)
            {
                WellView wellView = new WellView();
                wellView.DrawWell(Threshold, _i32GridSize, wells[i].DropletCount);
                int row = (int)(wells[i].WellIndex / _i32Cols) + 1;
                int column = wells[i].WellIndex % _i32Cols + 1;
                Grid.SetRow(wellView,row);
                Grid.SetColumn(wellView,column);
                _childGrid.Children.Add(wellView);
                _lstWellViews.Add(wellView);
                if(wells[i].DropletCount < _i32Threshold)
                {
                    _i32LowThresholdCount++;
                }
            }

            txtDropletThreshold.Text = "Droplet Threshold is " + _i32Threshold;
            txtWellCount.Text = "Total Well Count is " + wells.Length;
            txtLowWellCount.Text = "Total Well Count With Low Droplets is " + _i32LowThresholdCount;

        }

        public void UpdateThreshold(int Threshold)
        {
            _i32LowThresholdCount = 0;
            _i32Threshold = Threshold;
            foreach (WellView _wellView in _lstWellViews)
            {
                _wellView.Threshold = Threshold;
                if (_wellView.Value < Threshold)
                {
                    _i32LowThresholdCount++;
                }
                _wellView.FillEllipseColor();
            }

            txtDropletThreshold.Text = "Droplet Threshold is " + _i32Threshold;
            txtLowWellCount.Text = "Total Well Count With Low Droplets is " + _i32LowThresholdCount;

        }

        public void ClearGrid()
        {
            txtLowWellCount.Text = "";
            txtWellCount.Text = "";
            grdPlate.Children.Clear();
            _lstWellViews.Clear();
            _i32LowThresholdCount = 0;
        }

        #endregion
    }
}
