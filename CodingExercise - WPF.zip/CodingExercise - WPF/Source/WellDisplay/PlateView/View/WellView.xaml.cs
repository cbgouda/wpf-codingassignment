﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WellDisplay.PlateView
{
    /// <summary>
    /// Interaction logic for WellView.xaml
    /// This xaml is responsible for displaying the well data inside plate
    /// </summary>
    public partial class WellView : ContentControl
    {
        #region members

        private int _threshold;
        private int _value;

        #endregion

        #region constructor

        public WellView()
        {
            InitializeComponent();
        }

        #endregion

        #region properties

        public int Threshold
        {
            set { _threshold = value; }
            get { return _threshold; }
        }

        public int Value
        {
            set { _value = value; }
            get { return _value; }
        }

        #endregion

        #region Methods

        public void DrawWell(int Threshold, int GridSize, int Value)
        {
            txtValue.Height = GridSize-1;
            txtValue.Width = GridSize-1;
            txtValue.TextAlignment = TextAlignment.Center;

            wellCircle.Height = GridSize-1;
            wellCircle.Width = GridSize-1;
            wellCircle.VerticalAlignment = VerticalAlignment.Center;
            wellCircle.HorizontalAlignment = HorizontalAlignment.Center;
            txtValue.VerticalAlignment = VerticalAlignment.Center;
            txtValue.HorizontalAlignment = HorizontalAlignment.Center;

            _threshold = Threshold;
            _value = Value;
            FillEllipseColor();
        }

        public void FillEllipseColor()
        {
            if(_value < _threshold)
            {
                wellCircle.Fill = Brushes.Gray;
                txtValue.Text = "L";
            }
            else
            {
                wellCircle.Fill = Brushes.WhiteSmoke;
                txtValue.Text = "n";
            }
        }

        #endregion

    }
}
