﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WellDisplay.PlateView
{
    /// <summary>
    /// Interaction logic for PlateView.xaml
    /// This xaml file is responsible for wrapping the plate and displaying summary information
    /// </summary>
    public partial class PlateView : ContentControl
    {
        public PlateView()
        {
            InitializeComponent();
        }

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^[0-9]+");
            e.Handled = regex.IsMatch(e.Text);
            if (e.Handled == false)
                e.Handled = !(Convert.ToInt32(txtThresholdInput.Text + e.Text) < 501 && Convert.ToInt32(txtThresholdInput.Text + e.Text) >= 0);
        }
    }
}
