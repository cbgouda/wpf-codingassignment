﻿using Microsoft.Win32;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WellDisplay.CommonClasses;

namespace WellDisplay.PlateView
{
    public class PlateModel
    {
        #region Members

        private Plate _clsPlate;

        #endregion

        #region Constructor

        public PlateModel()
        {
            Threshold = Convert.ToInt32(ConfigurationManager.AppSettings["Threshold"]);
        }

        #endregion

        #region Properties

        public Plate PlateObject
        {
            get { return _clsPlate; }
        }
        public string ThresholdMessage { get; internal set; }

        public int Threshold
        {
            get
            {
                return Convert.ToInt32(ThresholdMessage);
            }
            set
            {
                ThresholdMessage = value.ToString();
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Select json file from File System and update respective objects and triger UI update
        /// </summary>
        /// <returns></returns>
        internal bool SelectPlateFile()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = "c:\\";
            openFileDialog.Filter = "json files (*.json)|*.json";
            openFileDialog.RestoreDirectory = true;
            var fileContent = string.Empty;
            var filePath = string.Empty;
            if (openFileDialog.ShowDialog() == true)
            {
                //Get the path of specified file
                filePath = openFileDialog.FileName;

                //Read the contents of the file into a stream
                var fileStream = openFileDialog.OpenFile();

                using (StreamReader reader = new StreamReader(fileStream))
                {
                    fileContent = reader.ReadToEnd();
                }

                _clsPlate = JsonConvert.DeserializeObject<Plate>(fileContent);
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion
    }
}
